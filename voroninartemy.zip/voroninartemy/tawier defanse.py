import pygame
import math
import random
import time

pygame.init()
WIDTH= 800
HEIGHT = 600
FramesPerSecond = 60
clock = pygame.time.Clock()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Тавер аф хел из роблокса")
bg = pygame.image.load("terka.png")
bg = pygame.transform.scale(bg, (WIDTH, HEIGHT))
color = (209, 23, 23)
a=10
money = 500
b=1
c=1

class Castle():
    def __init__(self, x, y, width, height):
        self.health=1000
        self.max_health = self.health
        self.width = 360
        self.height = 360
        self.image = pygame.image.load("piza.png")
        self.image = pygame.transform.scale(self.image, (width, height))
        self.rect = self.image.get_rect(topleft=(x, y))
        self.fired = False
        self.last_shot_time = 0
        self.shot_delay = c
        
    
    def draw(self):
        screen.blit(self.image, self.rect)
    def shoot(self):
        current_time = pygame.time.get_ticks()
        mouse_pos = pygame.mouse.get_pos()
        x_dist = mouse_pos[0] - self.rect.midleft[0]
        y_dist = -(mouse_pos[1] - self.rect.midleft[1])
        self.angle = math.degrees(math.atan2(y_dist, x_dist))
        pygame.draw.line(screen, (1, 1, 1), (self.rect.centerx, self.rect.centery), (mouse_pos))
        if (pygame.mouse.get_pressed()[0] == 1 and not self.fired and current_time - self.last_shot_time > self.shot_delay):
            self.fired=True
            self.last_shot_time = current_time
            arrow= Arrow(self.rect.midleft[0], self.rect.midleft[1], self.angle)
            arrows_group.add(arrow)
        if pygame.mouse.get_pressed()[2]==1:
           rx=random.randint(50, 750)
           bomb=Bomb(rx, 100)
           bomb_group.add(bomb)
        if pygame.mouse.get_pressed()[0] == 0:
            self.fired = False

        
        
def changeColor(image, color):
        coloredImage = pygame.Surface(image.get_size())
        coloredImage.fill(color)
        finalImage = image.copy()
        finalImage.blit(coloredImage, (0, 0), special_flags=pygame.BLEND_MULT)
        return finalImage

class Arrow(pygame.sprite.Sprite):
    def __init__(self, x, y, angle):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("bullet.png")
        self.image = pygame.transform.scale(self.image, (100, 100))
        self.image = pygame.transform.flip(self.image, True, False)
        self.image = pygame.transform.rotate(self.image, angle)
        self.rect = self.image.get_rect(center=(x, y))
        self.angle = math.radians(angle)
        self.speed = 10
        self.dx = math.cos(self.angle)*self.speed
        self.dy = -(math.sin(self.angle)*self.speed)

    def update(self):
        if self.rect.right < 0 or self.rect.left > WIDTH \
                or self.rect.bottom < 0 or self.rect.top > HEIGHT:
            self.kill()
        self.rect.x += self.dx
        self.rect.y += self.dy
class Bomb(pygame.sprite.Sprite):
    def __init__ (self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("bomb.png")
        self.image = pygame.transform.scale(self.image, (100, 200))
        self.rect = self.image.get_rect(center=(x,y))
        self.speed = 20
        self.by = 4
    def update(self, *args, **kwargs):
        self.rect.y +=self.by
class Enemy(pygame.sprite.Sprite):
    def __init__(self, image, x, y, width, height, health, speed, damage, reward):
        super().__init__()
        pygame.sprite.Sprite.__init__(self)
        self.health = health
        self.image = pygame.image.load(image)
        self.image = pygame.transform.scale(self.image, (width, height))
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 2
        self.attacking = False
        self.damage = 100
        self.attack_time_elapsed = 0
        self.damage = damage
        self.reward = reward


    def update(self, target):
        self.rect.x += self.speed
        global money

        if self.rect.right > target.rect.left:
            self.speed = 0
            self.attacking = True
        if self.attacking:
            dt = clock.tick()
            self.attack_time_elapsed += dt
            if self.attack_time_elapsed > 100:
                target.image = changeColor(target.image,(255,0,0))
                if self.attack_time_elapsed > 120:
                    self.attack_time_elapsed = 0
                    target.health -= self.damage
            else:
                target.image = pygame.image.load("piza.png")
                target.image = pygame.transform.scale(target.image, (target.width, target.height))
        for arrow in arrows_group:
            if self.rect.colliderect(arrow.rect):
                arrow.kill
                self.health -=b
                if self.health <=0:
                    money += self.reward
                    self.kill()
        for bomb in bomb_group:
            if self.rect.colliderect(bomb.rect):
                bomb.kill
                self.health -=0.2
                if self.health <=0:
                    self.kill()
def show_text(label, x, y, colour, font_size):
    f1 = pygame.font.Font(None, font_size)
    text = f1.render(label, True, colour)
    screen.blit(text, (x, y))
class button(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, image):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(image)
        self.image = pygame.transform.scale(self.image,(width, height))
        self.rect = self.image.get_rect(center=(x, y))
    def draw(self):
        action = False
        mouse_position = pygame.mouse.get_pos()
        if self.rect.collidepoint(mouse_position):
            if pygame.mouse.get_pressed()[0] == 1:
                action = True
        screen.blit(self.image, self.rect)
        return action
        
    
        

arrows_group = pygame.sprite.Group()
bomb_group=pygame.sprite.Group()
enemy_group=pygame.sprite.Group()
castle = Castle(500, 248, 360, 360)
dt = 0.5
time_to_spawn_enemy_elapsed = 0
spawn_time = 10


running = True
game_over = False
health_button = button(100,100,100,100, "heart.png")
arrow_button = button(220,100,100,100, "bow.png")
while running:
    clock.tick(FramesPerSecond)

    screen.blit(bg, (0, 0))
    show_text("Castle HP: %s" % castle.health, 400, 300, (0, 0, 0), 32)
    show_text("Money : %s" % money, 400, 200, (0, 0, 0), 32)

    castle.draw()
    castle.shoot()
    enemy_group.draw(screen)
    enemy_group.update(castle)
    arrows_group.draw(screen)
    arrows_group.update()
    bomb_group.draw(screen)
    bomb_group.update()

    if health_button.draw() and money >= 10:
        money -=10
        castle.health = castle.max_health
        print("buy healt")
    arrow_button.draw()
    if arrow_button.draw() and money >=500:
        money -= 500
        b+=1
        c=0
        print(b)


    time_to_spawn_enemy_elapsed +=dt
    #print(time_to_spawn_enemy_elapsed)
    if time_to_spawn_enemy_elapsed > spawn_time:
        spawn_time = random.randint(0, 100)
        time_to_spawn_enemy_elapsed = 0
        enemy_type = random.choice(["Hamster", "Spy", "Peter", "Richard", "Steve", "death", "beast", "sosed", "chicken"])
        enemy = None
        match enemy_type:
            case "Peter":
                enemy = Enemy("enemy.png", -300, 400, 150, 225, 100, True, 100, 10)
            case "Hamster":
                enemy = Enemy("Hamster.png", -300, 400, 125, 175, 100, True, 100, 10)
            case "Spy":
                enemy = Enemy("Spy.png", -300, 400, 150, 250, 100, True, 100, 10)
            case "Richard":
                enemy = Enemy("gimball.png", -300, 400, 200, 250, 100, True, 100, 10)
            case "Steve":
                enemy = Enemy("steve.png", -300, 400, 100, 250, 100, True, 100, 10)
            case "death":
                enemy = Enemy("smertVNishite.png", -300, 400, 150, 225, 100, True, 100, 10)
            case "beast":
                enemy = Enemy("beast.png", -300, 400, 150, 225, 100, True, 100, 10)
            case "sosed":
                enemy = Enemy("neighbor.png", -300, 400, 200, 225, 100, True, 100, 10)
            case "chicken":
                enemy = Enemy("chicken.png", -300, 400, 150, 225, 100, True, 100, 10)
        enemy_group.add(enemy)

    

    if game_over == False:
        if castle.health == 0:
            game_over = True
    else:
        show_text("GAME OVER, L", WIDTH // 2 - 150, HEIGHT // 2- 100, (255, 0 , 0), 72)
        for i in range(20):
            print("GAME OVER")
        time.sleep(1)
        time.sleep(2)
        running = False

    pygame.display.flip()

    

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    

pygame.quit()
#Найди и исправь все ошибки
