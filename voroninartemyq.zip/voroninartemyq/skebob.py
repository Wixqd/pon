import pygame
import random

rect2=(0, 0, 255)
rect1=(255, 0, 0)
color = (136, 108, 158)
yellow=(7, 247, 223)
speed=0.1
x=180
y=240
score=0
clock = pygame.time.Clock()
FPS=36000

WIDTH = 360
HEIGHT = 480

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))

running = True
while running:

    screen.fill((127, 150, 119))

    pygame.draw.rect(screen, (rect2), (0, 450, 180, 30))
    pygame.draw.rect(screen, (rect1), (180, 450, 180, 30))
    pygame.draw.circle(screen, (color), (x, y), 40)

    font = pygame.font.Font(None, 36)
    text=font.render("Score : %s" % score, True, (yellow))
    screen.blit(text, (40, 50))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                x-= 30
            if event.key == pygame.K_d:
                x+=30
    y+= speed
    if y > 410:
        pygame.display.flip()
        if x > 180:
            score-=1
            y=240
            x=random.randint(40, 320)
            speed*=1.5
        else:
            score+=1
            y=240
            x=random.randint(40, 320)
            speed*=1.5
    pygame.display.flip()
    

